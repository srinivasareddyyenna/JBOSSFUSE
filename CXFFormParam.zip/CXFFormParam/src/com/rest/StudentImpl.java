package com.rest;

import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;

@Service("studentService")
public class StudentImpl implements Student{

	@Override
	public Response insert(String sId, String sName) {
		String greetMessage = "values inserted successfully ID:" + sId + " , Student Name "+sName;
		return Response.status(200).entity(greetMessage).build();
	}

}
