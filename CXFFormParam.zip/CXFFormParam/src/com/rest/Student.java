package com.rest;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

@Path("/studentService")
public interface Student {
	@POST
	@Path("/insert")
	public Response insert(@FormParam("name") String sId, @FormParam("name2") String sName);

}
